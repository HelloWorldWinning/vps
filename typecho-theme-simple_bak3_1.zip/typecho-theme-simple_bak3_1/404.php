<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>




            <h2 class="title">404 - <?php _e('页面没找到'); ?></h2>
            <p><?php _e('你想查看的页面还没做'); ?></p>



    </div><!-- end #content-->
</section>
	<?php $this->need('footer.php'); ?>
