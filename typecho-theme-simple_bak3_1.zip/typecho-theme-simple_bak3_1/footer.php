<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>



<footer>
<div class="footer container">
    &copy; <?php echo date('Y'); ?> <?php _e('All Rights Reserved, Powered By <a href="http://typecho.org" target="_blank">Typecho</a>, Theme <a href="http://lhcy.org" target="_blank">Simple</a>.'); ?>
</div>
</footer>

        </div>
</div>

<?php $this->footer(); ?>
</body>
</html>
