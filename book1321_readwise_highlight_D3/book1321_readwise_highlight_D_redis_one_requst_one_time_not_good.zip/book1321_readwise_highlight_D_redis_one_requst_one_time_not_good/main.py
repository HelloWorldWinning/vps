from fastapi import FastAPI, HTTPException, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path
import pandas as pd
import json
import redis
import random
from typing import Optional, List

app = FastAPI()

# Redis connection
redis_client = redis.Redis(host='localhost', port=6379, db=0, decode_responses=True)

# Mount static files and setup templates
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def init_redis_data():
    """Initialize Redis with data from CSV files"""
    data_dir = Path("data")
    all_data = []

    # Read and combine all CSV files
    for csv_file in data_dir.glob("*.csv"):
        try:
            df = pd.read_csv(csv_file)
            df.columns = [col.replace(' ', '').lower() for col in df.columns]
            all_data.append(df)
        except Exception as e:
            print(f"Error reading {csv_file}: {e}")

    if not all_data:
        return

    combined_df = pd.concat(all_data, ignore_index=True)

    # Store highlights
    for idx, row in combined_df.iterrows():
        highlight_key = f"highlight:{idx}"
        redis_client.hmset(highlight_key, {
            'highlight': str(row.get('highlight', '')),
            'note': str(row.get('note', '')),
            'booktitle': str(row.get('booktitle', '')),
            'bookauthor': str(row.get('bookauthor', '')),
            'color': str(row.get('color', '')),
            'tags': str(row.get('tags', ''))
        })
        redis_client.sadd('highlight_ids', idx)

    # Store filters
    redis_client.sadd('filters:booktitles', *combined_df['booktitle'].dropna().unique())
    redis_client.sadd('filters:bookauthors', *combined_df['bookauthor'].dropna().unique())
    redis_client.sadd('filters:colors', *combined_df['color'].dropna().unique())

    # Process and store tags
    all_tags = set()
    for tags in combined_df['tags'].dropna():
        all_tags.update(tag.strip() for tag in str(tags).split(',') if tag.strip())
    redis_client.sadd('filters:tags', *all_tags)

# Initialize data on startup
@app.on_event("startup")
async def startup_event():
    try:
        init_redis_data()
    except Exception as e:
        print(f"Error initializing Redis: {e}")

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get('/favicon.ico', include_in_schema=False)
async def favicon():
    return FileResponse('static/favicon.ico')

@app.get("/api/highlight/random")
async def get_random_highlight(
    bookTitle: Optional[str] = None,
    bookAuthor: Optional[str] = None,
    tags: Optional[str] = None,
    color: Optional[str] = None
):
    """Get a random highlight based on filters"""
    try:
        # Get all highlight IDs
        highlight_ids = list(redis_client.smembers('highlight_ids'))

        if not highlight_ids:
            raise HTTPException(status_code=404, detail="No highlights found")

        # Apply filters
        filtered_ids = []
        for id in highlight_ids:
            highlight_key = f"highlight:{id}"
            highlight_data = redis_client.hgetall(highlight_key)

            if not highlight_data:
                continue

            matches = True
            if bookTitle and bookTitle != 'all':
                matches = matches and highlight_data.get('booktitle') == bookTitle
            if bookAuthor and bookAuthor != 'all':
                matches = matches and highlight_data.get('bookauthor') == bookAuthor
            if color and color != 'all':
                matches = matches and highlight_data.get('color') == color
            if tags and tags != 'all':
                highlight_tags = highlight_data.get('tags', '').split(',')
                matches = matches and tags in highlight_tags

            if matches:
                filtered_ids.append(id)

        if not filtered_ids:
            raise HTTPException(status_code=404, detail="No highlights found matching filters")

        # Select random highlight
        random_id = random.choice(filtered_ids)
        highlight_data = redis_client.hgetall(f"highlight:{random_id}")

        return highlight_data

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/filters")
async def get_filters():
    """Get all filter options from Redis"""
    try:
        filters = {
            "bookTitles": list(redis_client.smembers('filters:booktitles')),
            "bookAuthors": list(redis_client.smembers('filters:bookauthors')),
            "colors": list(redis_client.smembers('filters:colors')),
            "tags": list(redis_client.smembers('filters:tags'))
        }

        # Sort all filter lists
        for key in filters:
            filters[key] = sorted([item for item in filters[key] if item.strip()])

        return filters
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
